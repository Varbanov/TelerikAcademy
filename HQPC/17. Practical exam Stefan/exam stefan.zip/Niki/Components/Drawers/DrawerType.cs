﻿namespace ComputersSystem
{
    public enum DrawerType
    {
        Colorful, Monochrome,
    }
}
