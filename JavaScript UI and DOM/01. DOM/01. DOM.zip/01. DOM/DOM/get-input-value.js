﻿function getValue() {
    var element = document.getElementById("input");
    console.log(element.value);
}