﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.Models
{
    public enum BugStatus
    {
        Fixed = 0,
        Assigned = 1,
        ForTesting = 2,
        Pending = 3,
    }
}
