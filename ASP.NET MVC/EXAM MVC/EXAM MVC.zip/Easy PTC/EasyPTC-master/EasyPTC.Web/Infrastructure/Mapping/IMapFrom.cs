﻿namespace EasyPTC.Web.Infrastructure.Mapping
{
    public interface IMapFrom<T>
    {
    }
}
