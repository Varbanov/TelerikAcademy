﻿namespace ComputersSystem
{
    using System.Collections.Generic;

    public class Dell : AbstractComputerFactory
    {
        public override PersonalComputer MakePersonalComputer()
        {
            var ram = new Ram(8);
            var storage = new HardDrive(1000);
            var video = new ColorfullConsoleVideoCard();
            var cpu = new Cpu(4, 64, ram, video);
            var motherboard = new Motherboard(ram, video);

            var pc = new PersonalComputer(cpu, video, ram, storage, motherboard);
            return pc;
        }

        public override ServerComputer MakeServer()
        {
            var storageDrives = new List<HardDrive>();
            storageDrives.Add(new HardDrive(2000));
            storageDrives.Add(new HardDrive(2000));
            var storage = new HardDriveRaid(2000, 2, storageDrives);

            var ram = new Ram(64);

            var video = new MonochromeConsoleVideoCard();
            var cpu = new Cpu(8, 64, ram, video);
            var motherboard = new Motherboard(ram, video);

            var pc = new ServerComputer(cpu, video, ram, storage, motherboard);
            return pc;
        }

        public override LaptopComputer MakeLaptop()
        {
            var ram = new Ram(8);
            var storage = new HardDrive(1000);
            var video = new ColorfullConsoleVideoCard();
            var cpu = new Cpu(4, 32, ram, video);
            var motherboard = new Motherboard(ram, video);
            var battery = new LaptopBattery();

            var pc = new LaptopComputer(cpu, video, ram, storage, motherboard, battery);
            return pc;
        }
    }
}
