﻿//-----------------------------------------------------------------------
// <copyright file="IMotherboard.cs" company="Telerik">
//     Telerik AD
// </copyright>
// <summary>This is IMotherboard interface.</summary>
//-----------------------------------------------------------------------

namespace ComputersSystem
{
    using System;

    /// <summary>
    /// Provides public interface for loading values from RAM, saving values to RAM and sending data to video card.
    /// </summary>
    public interface IMotherboard
    {
        /// <summary>
        /// Loads an integer stored in the RAM, mounted on the motherBoard.
        /// </summary>
        /// <returns>The integer that is stored in the RAM.</returns>
        int LoadRamValue(); 

        /// <summary>
        /// Saves an integer number to the RAM, which is mounted on the motherBoard.
        /// </summary>
        /// <param name="value">The integer you want to save to the RAM.</param>
        void SaveRamValue(int value); 

        /// <summary>
        /// Passes command to the mounted video card to draw the data, passed as argument.
        /// </summary>
        /// <param name="data">The data that should be passed to the video card.</param>
        void DrawOnVideoCard(string data);
    }
}
