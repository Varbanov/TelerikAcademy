﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ComputersSystem;

namespace UnitTestProject1
{
    [TestClass]
    public class LaptopBatteryTests
    {
        private LaptopBattery battery = new LaptopBattery();

        [TestInitialize]
        public void CreateController()
        {
            this.battery = new LaptopBattery();
        }

        [TestMethod]
        public void ChargeCannotBeLessThanZero()
        {
            this.battery.Charge(-100);
            Assert.AreEqual(0, this.battery.Percentage);
        }

        [TestMethod]
        public void ChargeCannotBeGreaterThanOneHundred()
        {
            this.battery.Charge(100);
            Assert.AreEqual(100, this.battery.Percentage);
        }

        [TestMethod]
        public void ChargeWithZeroDoesNotChangePercentage()
        {
            this.battery.Charge(0);
            Assert.AreEqual(50, this.battery.Percentage);
        }
    

    }
}
