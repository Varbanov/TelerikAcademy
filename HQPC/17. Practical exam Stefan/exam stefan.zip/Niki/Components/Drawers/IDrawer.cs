﻿namespace ComputersSystem
{
    using System;

    public interface IDrawer
    {
        void Draw(string text);
    }
}
