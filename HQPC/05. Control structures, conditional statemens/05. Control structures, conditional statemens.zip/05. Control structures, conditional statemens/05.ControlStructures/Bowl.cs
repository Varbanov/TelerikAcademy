﻿using System;

public class Bowl
{
    public void Add(Vegetable vegetable) 
    {
        throw new NotImplementedException();
    }
}
