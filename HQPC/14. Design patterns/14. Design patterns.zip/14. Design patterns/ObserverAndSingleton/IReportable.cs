﻿namespace Singleton
{
    using System;

    public interface IReportable
    {
        void CreateReport();
    }
}
