﻿namespace ComputersSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public abstract class DriveStorage
    {
        public abstract int Capacity { get; set; }

        public abstract void SaveData(int address, string data);

        public abstract string LoadData(int address);
    }
}