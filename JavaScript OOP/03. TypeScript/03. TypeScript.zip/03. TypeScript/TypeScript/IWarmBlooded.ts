﻿interface IWarmBlooded extends IAnimal{
    bodyTemperature: number;
} 