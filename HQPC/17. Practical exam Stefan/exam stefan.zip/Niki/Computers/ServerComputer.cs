﻿namespace ComputersSystem
{
    using System.Collections.Generic;

    public class ServerComputer : IComputer, IServer
    {
        public ServerComputer(Cpu cpu, MonochromeConsoleVideoCard videoCard, Ram ram, DriveStorage storage, Motherboard motherboard)
        {
            this.Cpu = cpu;
            this.VideoCard = videoCard;
            this.Ram = ram;
            this.Storage = storage;
            this.MotherBoard = motherboard;
        }

        public Cpu Cpu { get; set; }

        public IDrawer VideoCard { get; set; }

        public Ram Ram { get; set; }

        public DriveStorage Storage { get; set; }

        public Motherboard MotherBoard { get; set; }

        public void Process(int data)
        {
            this.MotherBoard.SaveRamValue(data);
            this.Cpu.CalculateSquare();
        }
    }
}
