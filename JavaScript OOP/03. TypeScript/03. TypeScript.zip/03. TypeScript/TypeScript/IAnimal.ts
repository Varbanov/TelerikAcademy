﻿interface IAnimal {
    liveExpectancy: number;
    animalType: AnimalType;
    isAlive: boolean;
    age: number;
    
} 