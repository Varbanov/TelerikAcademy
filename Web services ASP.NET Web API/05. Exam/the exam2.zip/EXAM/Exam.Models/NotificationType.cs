﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exam.Models
{
    public enum NotificationType
    {
        GameWon = 0,
        GameLost = 1,
        YourTurn = 2,
        GameJoined = 3,
    }
}
