﻿define(function () {
    var books = [
       { author: 'William Shakespeare' },
       { author: 'William Shakespeare' },

       { author: 'Agatha Christie' },
       { author: 'Agatha Christie' },
       { author: 'Agatha Christie' },
       { author: 'Agatha Christie' },

       { author: 'Daniel Defoe' },
       { author: 'Daniel Defoe' },
       { author: 'Daniel Defoe' },

       { author: 'John Grisham' },
       { author: 'Christine Loren' },
       { author: 'Richard Kern' },
    ]

    return {
        books: books,
        task: 'All books',
    }
})