﻿using System.Web.UI;

namespace ChatChannel.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}