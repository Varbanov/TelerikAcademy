﻿namespace Decorator
{
    using System;

    public interface IVehicle
    {
        void MoveForward();

        void MoveBackward();
    }
}
