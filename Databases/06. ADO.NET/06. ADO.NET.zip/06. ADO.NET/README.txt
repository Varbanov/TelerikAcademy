For task 9:
Just run the script 
"MySQL Workbench book schema for task 9.sql"
to generate the corresponding database.
You may also need to edit the connection string.


For task 10:
Because with all packages, the archive exceeds the maximum
upload size of 16 MB in the Telerik Academy System, for task 10 
just install System.Data.SQLite Core (x86/x64) (find it in
the Visual Studio NuGet Package Manager).