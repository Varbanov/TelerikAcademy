﻿namespace ComputersSystem
{
    using System.Collections.Generic;

    public class LaptopComputer : ILaptop, IComputer
    {
        public LaptopComputer(Cpu cpu, IDrawer videoCard, Ram ram, DriveStorage storage, Motherboard motherboard, LaptopBattery battery)
        {
            this.Cpu = cpu;
            this.VideoCard = videoCard;
            this.Ram = ram;
            this.Storage = storage;
            this.MotherBoard = motherboard;
            this.Battery = battery;
        }

        public Cpu Cpu { get; set; }

        public IDrawer VideoCard { get; set; }

        public Ram Ram { get; set; }

        public DriveStorage Storage { get; set; }

        public Motherboard MotherBoard { get; set; }

        public LaptopBattery Battery { get; set; }

        public void Charge(int percentage)
        {
            this.Battery.Charge(percentage);
            var message = string.Format("Battery status: {0}%", this.Battery.Percentage);
            this.VideoCard.Draw(message);
        }
    }
}
