﻿//# sourceMappingURL=IWarmBlooded.js.map
