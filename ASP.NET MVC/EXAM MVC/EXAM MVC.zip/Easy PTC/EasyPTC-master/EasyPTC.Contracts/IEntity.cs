﻿namespace EasyPTC.Data.Contracts
{
    public interface IEntity
    {
    }
}
