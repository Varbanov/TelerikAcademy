﻿var AnimalType;
(function (AnimalType) {
    AnimalType[AnimalType["Reptile"] = 0] = "Reptile";
    AnimalType[AnimalType["WarmBlooded"] = 1] = "WarmBlooded";
})(AnimalType || (AnimalType = {}));
//# sourceMappingURL=animalType.js.map
