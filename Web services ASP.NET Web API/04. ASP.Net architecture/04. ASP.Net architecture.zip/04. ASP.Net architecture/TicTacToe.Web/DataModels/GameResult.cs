namespace TicTacToe.Web.DataModels
{
    public enum GameResult
    {
        NotFinished,
        XWins,
        OWins,
        Draw,
    }
}