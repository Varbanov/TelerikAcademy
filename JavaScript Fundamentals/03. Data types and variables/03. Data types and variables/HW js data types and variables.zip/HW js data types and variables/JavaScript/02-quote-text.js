﻿var str = "'How you doin'?', Joey said.";
console.log(str);