﻿function calcRectangleArea(width, height) {
    width = parseFloat(width);
    height = parseFloat(height);
    var area = width * height;
    jsConsole.writeLine("The rectangle's area is " + area);
}