﻿namespace ComputersSystem
{
    using System;

    public static class DrawerFactory
    {
        public static IDrawer GetDrawer(DrawerType type)
        {
            switch (type)
            {
                case DrawerType.Colorful:
                    return new ColorfullConsoleVideoCard();
                case DrawerType.Monochrome:
                    return new MonochromeConsoleVideoCard();
                default:
                    throw new NotImplementedException("The chosen video card is not supported by the video card factory yet");
            }
        }
    }
}
