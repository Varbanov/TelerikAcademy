﻿define(function () {
    var people = [
         { id: 1, name: "Doncho Minkov", age: 25, avatarUrl: "images/minkov.jpg" },
         { id: 2, name: "Georgi Georgiev", age: 22, avatarUrl: "images/joreto.jpg" },
         { id: 2, name: "Nikolay Kostov", age: 25, avatarUrl: "images/niki.png" },
         { id: 2, name: "Ivaylo Kenov", age: 24, avatarUrl: "images/kenov.jpg" },

    ];

    return people;
});