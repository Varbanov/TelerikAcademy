﻿namespace ComputersSystem
{
    using System.Collections.Generic;

    public class PersonalComputer : IComputer
    {
        public PersonalComputer(Cpu cpu, IDrawer videoCard, Ram ram, DriveStorage storage, Motherboard motherboard)
        {
            this.Cpu = cpu;
            this.VideoCard = videoCard;
            this.Ram = ram;
            this.Storage = storage;
            this.MotherBoard = motherboard;
        }

        public Cpu Cpu { get; set; }

        public IDrawer VideoCard { get; set; }

        public Ram Ram { get; set; }

        public DriveStorage Storage { get; set; }

        public Motherboard MotherBoard { get; set; }

        public void Play(int guessNumber)
        {
            this.Cpu.GenerateRandomNumber(1, 10);
            var number = this.Ram.LoadValue();
            if (number != guessNumber)
            {
                var message = string.Format("You didn't guess the number {0}.", number);
                this.VideoCard.Draw(message);
            }
            else
            {
                this.VideoCard.Draw("You win!");
            }
        }
    }
}
