﻿namespace ComputersSystem
{
    using System;

    public enum ComputerType
    {
        Pc, Laptop, Server, 
    }
}
