﻿using Exam.Data;
using Exam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main()
        {
            ExamData dbContext = new ExamData();

            dbContext.Model1s.Add(new Model1());
            var p = dbContext.SaveChanges();
            Console.WriteLine(p);
        }
    }
}
