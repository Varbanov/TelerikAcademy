﻿namespace ComputersSystem
{
    using System;

    public class MonochromeConsoleVideoCard : IDrawer
    {
        public void Draw(string text)
        {
            Console.WriteLine(text);
            Console.ResetColor();
        }
    }
}
