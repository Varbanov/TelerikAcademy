﻿using System.Web.UI;

namespace NewsExam.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}