﻿namespace ComputersSystem
{
    public class Motherboard : IMotherboard
    {
        public Motherboard(IRam ram, IDrawer videoCard)
        {
            this.Ram = ram;
            this.VideoCard = videoCard;
        }

        public IRam Ram { get; set; }

        public IDrawer VideoCard { get; set; }

        public int LoadRamValue()
        {
            return this.Ram.LoadValue();
        }

        public void SaveRamValue(int value)
        {
            this.Ram.SaveValue(value);
        }

        public void DrawOnVideoCard(string data)
        {
            this.VideoCard.Draw(data);
        }
    }
}
