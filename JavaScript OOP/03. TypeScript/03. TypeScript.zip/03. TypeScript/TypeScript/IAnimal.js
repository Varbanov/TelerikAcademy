﻿//# sourceMappingURL=IAnimal.js.map
