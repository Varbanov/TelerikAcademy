﻿namespace ComputersSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class SpecialCpu : Cpu
    {
        public SpecialCpu(byte numberOfCores, Ram ram, IDrawer videoCard)
            : base(numberOfCores, 128, ram, videoCard)
        {
        }

        public override void CalculateSquare()
        {
            var data = this.Ram.LoadValue();
            if (data < 0)
            {
                this.VideoCard.Draw("Number too low.");
            }
            else if (data > 2000)
            {
                this.VideoCard.Draw("Number too high.");
            }
            else
            {
                int squaredData = data * data;
                this.VideoCard.Draw(string.Format("Square of {0} is {1}.", data, squaredData));
            }
        }
    }
}
