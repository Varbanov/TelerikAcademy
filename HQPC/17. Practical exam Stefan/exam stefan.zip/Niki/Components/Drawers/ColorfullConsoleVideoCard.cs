﻿namespace ComputersSystem
{
    using System;

    public class ColorfullConsoleVideoCard : IDrawer
    {
        public void Draw(string text)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(text);
            Console.ResetColor();
        }
    }
}
