﻿define(function () {
    var animals = [
        { species: 'crocodile', legs: 4 },
        { species: 'rhino', legs: 4 },
        { species: 'ant', legs: 6 },
        { species: 'ant', legs: 8 },
        { species: 'ant', legs: 100 },
        { species: 'centipede', legs: 100 },
        { species: 'cat', legs: 4 },
        { species: 'hen', legs: 2 },
        { species: 'beetle', legs: 8 },
        { species: 'beetle', legs: 4 },
        { species: 'beetle', legs: 6 },

    ]

    return {
        animals: animals,
        task: "All animals: ",
    }
})