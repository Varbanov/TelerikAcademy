﻿namespace ComputersSystem
{
    using System;
    using System.Collections.Generic;

    public class ComputersSystemMain
    {
        private static void Main()
        {
            var hp = new Hp();
            var dell = new Dell();
            var lenovo = new Lenovo();

            IComputer pc;
            IComputer laptop;
            IComputer server;
            var manufacturer = Console.ReadLine();

            if (manufacturer == "HP")
            {
                pc = hp.MakePersonalComputer();
                laptop = hp.MakeLaptop();
                server = hp.MakeServer();
            }
            else if (manufacturer == "Dell")
            {
                pc = dell.MakePersonalComputer();
                laptop = dell.MakeLaptop();
                server = dell.MakeServer();
            }
            else if (manufacturer == "Lenovo")
            {
                pc = lenovo.MakePersonalComputer();
                laptop = lenovo.MakeLaptop();
                server = lenovo.MakeServer();
            }
            else
            {
                throw new InvalidArgumentException("Invalid manufacturer!");
            }

            while (true)
            {
                var currentCommandLine = Console.ReadLine();
                if (currentCommandLine == null)
                {
                    return;
                }

                if (currentCommandLine.StartsWith("Exit"))
                {
                    return;
                }

                var commandVariables = currentCommandLine.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                if (commandVariables.Length != 2)
                {
                    throw new ArgumentException("Invalid command!");
                }

                var commandName = commandVariables[0];
                var commandArgument = int.Parse(commandVariables[1]);

                if (commandName == "Charge")
                {
                    ((LaptopComputer)laptop).Charge(commandArgument);
                }
                else if (commandName == "Process")
                {
                    ((ServerComputer)server).Process(commandArgument);
                }
                else if (commandName == "Play")
                {
                    ((PersonalComputer)pc).Play(commandArgument);
                }
            }
        }
    }
}
