﻿namespace ComputersSystem
{
    public interface IServer
    {
        void Process(int data);
    }
}
