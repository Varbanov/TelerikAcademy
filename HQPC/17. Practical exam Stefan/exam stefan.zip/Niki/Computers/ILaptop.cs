﻿namespace ComputersSystem
{
    public interface ILaptop
    {
        LaptopBattery Battery { get; }

        void Charge(int percentage);
    }
}
