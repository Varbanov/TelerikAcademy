﻿function OnColorBtnClick() {
    document.body.style.backgroundColor = document.getElementById("backgroundColor").value;
}