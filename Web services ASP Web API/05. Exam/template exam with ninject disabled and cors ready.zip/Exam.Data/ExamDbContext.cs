﻿namespace Exam.Data
{
    using Exam.Data.Migrations;
    using Exam.Models;
    using Microsoft.AspNet.Identity.EntityFramework;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public class ExamDbContext : IdentityDbContext<ApplicationUser>
    {
        public ExamDbContext()
            : base("DefaultConnection", throwIfV1Schema: false)
        {
        }

        public static ExamDbContext Create()
        {
            return new ExamDbContext();
        }

        public IDbSet<Model1> Model1 { get; set; }
        public IDbSet<Model2> Model2 { get; set; }
        public IDbSet<Model3> Model3 { get; set; }
        public IDbSet<Model4> Model4 { get; set; }
        public IDbSet<Model5> Model5 { get; set; }

        // TODO stefan maybe remove this 
        //public new void SaveChanges()
        //{
        //    base.SaveChanges();
        //}
    }
}
