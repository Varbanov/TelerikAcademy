﻿enum AnimalType {
    Reptile,
    WarmBlooded
} 