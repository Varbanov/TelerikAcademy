﻿namespace Singleton
{
    using System;

    public enum ChangeType
    {
        IN, OUT
    }
}
