﻿using Exam.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Web;

namespace Exam.WebServices.Models
{
    public class ScoreModel
    {
        public string Username { get; set; }
        public int Rank { get; set; }
    }
}