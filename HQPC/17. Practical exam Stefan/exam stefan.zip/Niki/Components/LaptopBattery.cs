﻿namespace ComputersSystem
{
    public class LaptopBattery
    {
        public LaptopBattery() 
        {
            this.Percentage = 50;
        }

        public int Percentage { get; private set; }

        public void Charge(int percentage)
        {
            var chargedValue = this.Percentage += percentage;
            if (this.Percentage > 100)
            {
                this.Percentage = 100;
                return;
            }
            else if (this.Percentage < 0)
            {
                this.Percentage = 0;
                return;
            }

            this.Percentage = chargedValue;
        }
    }
}
