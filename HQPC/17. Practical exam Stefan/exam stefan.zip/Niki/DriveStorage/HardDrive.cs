﻿namespace ComputersSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class HardDrive : DriveStorage
    {
        // SortedDictionary<int, string> info;
        private Dictionary<int, string> data;

        public HardDrive(int capacity)
        {
            this.Capacity = capacity;
            this.data = new Dictionary<int, string>();
        }

        public override int Capacity { get; set; }

        public override void SaveData(int address, string data)
        {
            this.data[address] = data;
        }

        public override string LoadData(int address)
        {
            return this.data[address];
        }
    }
}
