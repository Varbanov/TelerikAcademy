﻿using System;

public class Potato : Vegetable
{
    public bool IsPeeled { get; set; }

    public bool IsRotten { get; set; }
}