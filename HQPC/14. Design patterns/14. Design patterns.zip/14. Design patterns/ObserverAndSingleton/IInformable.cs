﻿namespace Singleton
{
    using System;

    public interface IInformable
    {
        void Inform(string information);
    }
}
