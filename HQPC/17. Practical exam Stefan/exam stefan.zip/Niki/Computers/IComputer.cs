﻿namespace ComputersSystem
{
    public interface IComputer
    {
        Cpu Cpu { get; }

        IDrawer VideoCard { get; }

        Ram Ram { get; }
    }
}
