﻿using System;

public class Vegetable
{
}