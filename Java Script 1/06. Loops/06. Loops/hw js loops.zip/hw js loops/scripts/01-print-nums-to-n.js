﻿function printNums(n) {
    for (var i = 1; i <= n; i++) {
        jsConsole.write(i + " ");
    }
}