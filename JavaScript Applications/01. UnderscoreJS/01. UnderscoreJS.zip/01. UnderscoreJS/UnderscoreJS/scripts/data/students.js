﻿define(function () {
    var students = [
        { fname: 'Pesho', lname: 'Ivanov', age: 22, mark: 2 },
        { fname: 'Elena', lname: 'Marinova', age: 18, mark: 6 },
        { fname: 'Maria', lname: 'Georgieva', age: 27, mark: 4 },
        { fname: 'Georgi', lname: 'Dimitrov', age: 20, mark: 6 },
        { fname: 'Elena', lname: 'Pesheva', age: 21, mark: 4 },
        { fname: 'Ivan', lname: 'Ivanov', age: 18, mark: 5 },
        { fname: 'Asya', lname: 'Petrova', age: 25, mark: 6 },
    ]

    return {
        students: students,
        task: "All Students:",
    }
})