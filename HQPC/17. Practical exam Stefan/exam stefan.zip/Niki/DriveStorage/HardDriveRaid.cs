﻿namespace ComputersSystem
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class HardDriveRaid : DriveStorage
    {
        private int numberOfHardDrives;
        private List<HardDrive> raid;

        // SortedDictionary<int, string> info;
        private Dictionary<int, string> data;

        public HardDriveRaid(int capacity, int numberOfHardDrives, List<HardDrive> raidHardDrives)
        {
            this.numberOfHardDrives = numberOfHardDrives;
            this.Capacity = capacity;
            this.data = new Dictionary<int, string>(capacity);
            this.raid = raidHardDrives;
        }

        public override int Capacity { get; set; }

        public override void SaveData(int address, string newData)
        {
            foreach (var hardDrive in this.raid)
            {
                hardDrive.SaveData(address, newData);
            }
        }

        public override string LoadData(int address)
        {
            if (!this.raid.Any())
            {
                throw new OutOfMemoryException("No hard drive in the RAID array!");
            }

            return this.raid.First().LoadData(address);
        }
    }
}