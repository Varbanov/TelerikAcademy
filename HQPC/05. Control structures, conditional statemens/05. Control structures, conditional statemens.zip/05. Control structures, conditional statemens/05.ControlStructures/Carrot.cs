﻿using System;

public class Carrot : Vegetable
{
}