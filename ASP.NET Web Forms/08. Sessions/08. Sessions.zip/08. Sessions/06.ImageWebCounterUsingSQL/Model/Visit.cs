﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _06.ImageWebCounterUsingSQL.Model
{
    public class Visit
    {
        public int VisitId { get; set; }
        public int VisitCount { get; set; }
    }
}