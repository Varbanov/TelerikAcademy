﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace _01.CarsSearch
{
    public class Extra
    {
        public string Name { get; set; }

        public Extra(string name)
        {
            this.Name = name;
        }
    }
}