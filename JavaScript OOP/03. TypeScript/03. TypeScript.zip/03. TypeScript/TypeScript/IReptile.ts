﻿interface IReptile extends IAnimal {
    isAmphibian: boolean;
}