﻿namespace ComputersSystem
{
    public abstract class AbstractComputerFactory
    {
        public abstract PersonalComputer MakePersonalComputer();

        public abstract ServerComputer MakeServer();

        public abstract LaptopComputer MakeLaptop();
    }
}
