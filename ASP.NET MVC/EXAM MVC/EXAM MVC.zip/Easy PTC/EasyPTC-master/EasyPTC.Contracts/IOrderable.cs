﻿namespace EasyPTC.Data.Contracts
{
    public interface IOrderable
    {
        int OrderBy { get; set; }
    }
}
