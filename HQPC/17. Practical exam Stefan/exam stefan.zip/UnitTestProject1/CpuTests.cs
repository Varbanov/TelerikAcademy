﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ComputersSystem;

namespace CpuTests
{
    [TestClass]
    public class CpuTests
    {
        private Cpu  cpu = new Cpu(2,2,new Ram(2), new MonochromeConsoleVideoCard());

        [TestInitialize]
        public void CreateController()
        {
            this.cpu = new Cpu(2, 2, new Ram(2), new MonochromeConsoleVideoCard());
        }


        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
