﻿namespace ComputersSystem
{
    using System;

    public class Cpu
    {
        protected static readonly Random Random = new Random();
        protected readonly byte NumberOfBits;
        protected readonly Ram Ram;
        protected readonly IDrawer VideoCard;

        public Cpu(byte numberOfCores, byte numberOfBits, Ram ram, IDrawer videoCard)
        {
            this.NumberOfBits = numberOfBits;
            this.Ram = ram;
            this.NumberOfCores = numberOfCores;
            this.VideoCard = videoCard;
        }

        public byte NumberOfCores { get; set; }

        public virtual void CalculateSquare()
        {
            var data = this.Ram.LoadValue();

            if (this.NumberOfBits == 32)
            {
                this.CalculateSquareNumber32Bit(data);
            }

            if (this.NumberOfBits == 64)
            {
                this.CalculateSquareNumber64(data);
            }
        }

        public void GenerateRandomNumber(int min, int max)
        {
            int randomNumber = Random.Next(min, max);
            this.Ram.SaveValue(randomNumber);
        }

        private void CalculateSquareNumber32Bit(int data)
        {
            if (data < 0)
            {
                this.VideoCard.Draw("Number too low.");
            }
            else if (data > 500)
            {
                this.VideoCard.Draw("Number too high.");
            }
            else
            {
                int squaredData = data * data;
                this.VideoCard.Draw(string.Format("Square of {0} is {1}.", data, squaredData));
            }
        }

        private void CalculateSquareNumber64(int data)
        {
            if (data < 0)
            {
                this.VideoCard.Draw("Number too low.");
            }
            else if (data > 1000)
            {
                this.VideoCard.Draw("Number too high.");
            }
            else
            {
                int squaredData = data * data;
                this.VideoCard.Draw(string.Format("Square of {0} is {1}.", data, squaredData));
            }
        }
    }
}
